<?php
$smtphost = "smtp.sendgrid.net"; // SMTP Host Name
$smtpuser = ''; // SMTP User Name
$smtppass = ''; // SMTP password
?>