<?php
//$conn = 'mysql:host=localhost;dbname=econneck_login-portal';
//$conn = new PDO($dsn, 'econneck_login', 'loginportal');
?>


<?php

$host='localhost';
$db = 'login_pf';
$username = 'root';
$password = '';

 
$dsn= "mysql: host=$host;dbname=$db";
 
try{
 // create a PDO connection with the configuration data
 $conn = new PDO($dsn, $username, $password);
 
 // display a message if connected to database successfully
 if($conn){
 //echo "Connected to the <strong>$db</strong> database successfully!";
        }
}catch (PDOException $e){
 // report error message
 echo $e->getMessage();
}

?>



<?php
//$dsn = 'mysql:host=localhost;dbname=login-portal';
//$db = new PDO($dsn, 'root', '');
?>