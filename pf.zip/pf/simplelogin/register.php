<?php ob_start();
session_start();
require_once('includes/connect.php');
require_once('if-loggedin.php');
include('includes/header.php');
if(isset($_POST) & !empty($_POST)){
    // PHP Form Validations
    if(empty($_POST['username'])){ $errors[]="User Name field is Required"; }else{
        // Check Username is Unique with DB query
        $sql = "SELECT * FROM users WHERE username=?";
        $result = $conn->prepare($sql);
        $result->execute(array($_POST['username']));
        $count = $result->rowCount();
        if($count == 1){
            $errors[] = "User Name already exists in database";
        }
    }
    if(empty($_POST['email'])){ $errors[]="E-mail field is Required"; }else{
        // Check Email is Unique with DB Query
        $sql = "SELECT * FROM users WHERE email=?";
        $result = $conn->prepare($sql);
        $result->execute(array($_POST['email']));
        $count = $result->rowCount();
        if($count == 1){
            $errors[] = "E-Mail already exists in database";
        }
    }
    if(empty($_POST['mobile'])){ $errors[]="Mobile field is Required"; }
    if(empty($_POST['password'])){ $errors[]="Password field is Required"; }else{
        // check the repeat password
        if(empty($_POST['passwordr'])){ $errors[]="Repeat Password field is Required"; }else{
            // compare both passwords, if they match. Generate the Password Hash
            if($_POST['password'] == $_POST['passwordr']){
                // create password hash
                $pass_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
            }else{
                // Display Error Message
                $errors[] = "Both Passwords Should Match";
            }
        }
    }

    // CSRF Token Validation
    if(isset($_POST['csrf_token'])){
        if($_POST['csrf_token'] === $_SESSION['csrf_token']){
        }else{
			header("location: /pf/index.php");
            //$errors[] = "Problem with CSRF Token Validation";
        }
    }
    // CSRF Token Time Validation
    $max_time = 60*60*24; // in seconds
    if(isset($_SESSION['csrf_token_time'])){
        $token_time = $_SESSION['csrf_token_time'];
        if(($token_time + $max_time) >= time() ){
        }else{
            $errors[] = "CSRF Token Expired";
            unset($_SESSION['csrf_token']);
            unset($_SESSION['csrf_token_time']);
        }
    }

    // If no Errors, Insert the Values into users table
    if(empty($errors)){
        $sql = "INSERT INTO users (username, email, password) VALUES (:username, :email, :password)";
        $result = $conn->prepare($sql);
        $values = array(':username'     => $_POST['username'],
                        ':email'        => $_POST['email'],
                        ':password'     => $pass_hash
                        );
        $res = $result->execute($values);
        if($res){
            $messages[] = "User Registered";
            // get the id from last insert query and insert a new record into user_info table with mobile number
            $userid = $conn->lastInsertID();
            $uisql = "INSERT INTO user_info (uid, mobile) VALUES (:uid, :mobile)";
            $uiresult = $conn->prepare($uisql);
            $values = array(':uid'          => $userid,
                            ':mobile'       => $_POST['mobile']
                            );
            $uires = $uiresult->execute($values) or die(print_r($result->errorInfo(), true));
            if($uires){
                $messages[] = "Added User Meta Information";
				header("Location: index.php");
            }

        }
    }
}
// CSRF Protection
// 1. Create CSRF token
$token = md5(uniqid(rand(), TRUE));
$_SESSION['csrf_token'] = $token;
$_SESSION['csrf_token_time'] = time();

// 2. add CSRF token to form
// 3. check the CSRF token on form submission
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>PF - Personal Finance Software</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="includes/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="includes/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="includes/fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="includes/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="includes/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="includes/vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="includes/vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="includes/vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="includes/css/util.css">
	<link rel="stylesheet" type="text/css" href="includes/css/main.css">
<!--===============================================================================================-->
</head>



<div class="container-login100" style="background-image: url('../img/finance.jpg');">
    <div class="wrap-login100 p-l-55 p-r-55 p-t-80 p-b-30">
                    <?php
                        if(!empty($errors)){
                            echo "<div class='alert alert-danger'>";
                            foreach ($errors as $error) {
                                echo "<span class='glyphicon glyphicon-remove'></span>&nbsp;".$error."<br>";
                            }
                            echo "</div>";
                        }
                    ?>
                    <?php
                        if(!empty($messages)){
                            echo "<div class='alert alert-success'>";
                            foreach ($messages as $message) {
                                echo "<span class='glyphicon glyphicon-ok'></span>&nbsp;".$message."<br>";
                            }
                            echo "</div>";
                        }
                    ?>
                    <form role="form" method="post" class="login100-form validate-form" AUTOCOMPLETE="OFF">
                        <input type="hidden" name="csrf_token" value="<?php echo $token; ?>">
						<span class="login100-form-title p-b-37">
					       Please Sign In
				        </span>
						  <div class="wrap-input100 validate-input m-b-20" data-validate="Enter username">
				            <input class="input100" placeholder="User Name" name="username" type="text" autofocus value="<?php if(isset($_POST['username'])){ echo $_POST['username']; } ?>">
				             <span class="focus-input100"></span>
				          </div>
                            <div class="wrap-input100 validate-input m-b-20" data-validate="Enter email">
                                <input class="input100" placeholder="E-mail" name="email" type="email" value="<?php if(isset($_POST['email'])){ echo $_POST['email']; } ?>">
                                <span class="focus-input100"></span>
							</div>
                            <div class="wrap-input100 validate-input m-b-20" data-validate="Enter Mobile">
                                <input class="input100" placeholder="Mobile" name="mobile" type="text" value="<?php if(isset($_POST['mobile'])){ echo $_POST['mobile']; } ?>">
                                <span class="focus-input100"></span>
							</div>
                            <div class="wrap-input100 validate-input m-b-20" data-validate="Enter password">
                                <input class="input100" placeholder="Password" name="password" type="password" value="">
                                <span class="focus-input100"></span>
							</div>
                            <div class="wrap-input100 validate-input m-b-20" data-validate="Repeat Password">
                                <input class="input100" placeholder="Repeat Password" name="passwordr" type="password" value="">
                                <span class="focus-input100"></span>
							</div>
                            <!-- Change this to a button or input when using this as a form -->
                            <div class="container-login100-form-btn">
				               <input type="submit" class="login100-form-btn" value="Jisajiri / Register" />
				            </div>
                    </form>

	
	<!--===============================================================================================-->
	<script src="includes/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="includes/vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="includes/vendor/bootstrap/js/popper.js"></script>
	<script src="includes/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="includes/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="includes/vendor/daterangepicker/moment.min.js"></script>
	<script src="includes/vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="includes/vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="includes/js/main.js"></script>	
<?php include('includes/footer.php'); ?>