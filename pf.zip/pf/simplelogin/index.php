<?php ob_start();
session_start();
header('Location: /pf/index.php');

?>