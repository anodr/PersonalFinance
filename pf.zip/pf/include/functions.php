<?php ob_start(); ?>
<?php require_once("DB.php"); ?>
<?php require_once("sessions.php"); ?>

<?php
//function Redirect_to($New_Location){
//    header("Location:".$New_Location);
//	exit;
//}

function Login_Attempt($username,$password){
	$ConnectingDB;
	$connection=mysqli_connect("localhost","econneck_logisti","jz==jOwusq,_"," econneck_logistics");
	$query="SELECT * FROM registration WHERE username='$username' AND password='$password'";
	$result=mysqli_query($connection, $query);
	if($admin=mysqli_fetch_assoc($result)){
		return $admin;
	}else
		return null;
}

function Login(){
	if(isset($_SESSION["username"])){
		return true;
	}
}
function Confirm_Login(){
	if(!Login()){
		$_SESSION["ErrorMessage"]="Login Required";
		header("Location: ../register/login.php");
	}
}

function ConfirmFrontPage_Login(){
	if(!Login()){
		$_SESSION["ErrorMessage"]="Login Required";
		header("Location: ../ezpos/register/login.php");
	}
}

?>