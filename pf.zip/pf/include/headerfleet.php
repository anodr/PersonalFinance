<?php ob_start(); ?>
<?php session_start(); ?>
<?php require_once("../include/DB.php"); ?>
<?php //require_once("../include/sessions.php"); ?> 
<?php require_once("functions.php"); ?>
<?php //Confirm_Login(); ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Fleet Management System</title>
  <meta charset="utf-8">
  
<link rel="apple-touch-icon" sizes="180x180" href="../favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../favicon/favicon-16x16.png">
<link rel="shortcut icon" href="../favicon/favicon.ico">
<link rel="manifest" href="../favicon/site.webmanifest">
<link rel="mask-icon" href="../favicon/safari-pinned-tab.svg" color="#5bbad5">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">
  
  <meta http-equiv="expires" content="Sun, 01 Jan 2014 00:00:00 GMT"/>
  <meta http-equiv="pragma" content="no-cache" />
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <!-- You can use Open Graph tags to customize link previews.
    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->
  <meta property="fb:app_id"        content="161336481463790" 
  <meta property="og:url"           content="http://econneckt.com/logistics/ground"/> 
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="Fleet Management System" />
  <meta property="og:description"   content="Web based system incorporating functions such as vehicle maintenance, fuel management, finance, and management of the fleet drivers" />
  <meta property="og:image"         content="http://econneckt.com/images/fl.jpg" />
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="elinc/style.css">
 <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
  <link rel="stylesheet" href="font-awesome-animation.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/js/gijgo.min.js" type="text/javascript"></script>
  <link href="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/css/gijgo.min.css" rel="stylesheet" type="text/css" />
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.23/angular.min.js"></script>
  <script src="http://code.jquery.com/jquery-1.4.3.min.js"></script>	
  
  
  <style>
  .description{
	color:#566573;
   margin-top:1px;
  }
  a:link{
  color:#115587;
  text-decoration:none;
  }
  
a:hover{
  text-decoration:none;
  color:#0C7C2B;
  }
  
  .vl {
    border-left: 2px solid gray;
    height: 25rem;
}
  

.videowrapper {
    float: none;
    clear: both;
    width: 100%;
    position: relative;
    padding-bottom: 56.25%;
    padding-top: 25px;
    height: 0;
}
.videowrapper iframe {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

body{
    padding-left:;
	padding-right:;
	padding-bottom:2rem;
	padding-top:1rem;
}
 
 </style>
  
</head>


<div class="container-fluid">
 <div class="row">
   <div class="col-md-4">
    <a class="navbar-brand" href="index.php"><h4>ABC Manufacturing Co. Limited</h4></a>
   </div><br>

    <div class="col-md-5">
	  <form class="form-inline" action="index.php" style="margin:auto; width:100%;">
      <input class="form-control mb-2 mr-sm-2" name="Search" type="text" placeholder="Search" style="margin:auto; width:80%;">
       <button class="btn btn-outline-success my-sm-2" type="submit" name="SearchButton">Search</button>
     </form>
   </div><br>
   
    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
        <div class="dropdown pull-right">
         <a class="dropdown-toggle " href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
           <?php echo $_SESSION['username']; ?>
          </a>

         <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
          <a class="dropdown-item" href="../register/logout.php">Logout</a>
         </div>
        </div>
    </div>
   
   </div>
  

  <div style="height:1px; background:#27aae1;"></div>
   <nav class="navbar navbar-expand-sm navbar-light">
  	<ul class="navbar-nav">
       <li class="nav-item">
         <a class="nav-link" href="../../logistics/index.php"><span class="h5"><i class="fa fa-home"></i>&nbsp;Logistics Management Software</span></a>
       </li>
	    <li class="nav-item">
         <a class="nav-link" href="../../logistics/rawproducts/"><span class="h5 strong" style="color:#f5571c;">|&nbsp;<strong>RAW PRODUCTS</strong></span></a>
       </li>
	    <li class="nav-item">
         <a class="nav-link" href="../../logistics/endproducts/"><span class="h5" style="color:#f5571c;">|&nbsp;<strong>END PRODUCTS</strong></span></a>
       </li>
	    <li class="nav-item">
         <a class="nav-link" href="../../logistics/customers/"><span class="h5" style="color:#f5571c;">|&nbsp;<strong>CUSTOMERS</strong></span></a>
       </li>
	   <li class="nav-item">
         <a class="nav-link" href="../../logistics/suppliers/"><span class="h5" style="color:#f5571c;">|&nbsp;<strong>SUPPLIERS</strong></span></a>
       </li>
	   <li class="nav-item">
         <a class="nav-link" href="../../logistics/warehouse/"><span class="h5" style="color:#f5571c;">|&nbsp;<strong>WAREHOUSE</strong></span></a>
       </li>
	   <li class="nav-item">
         <a class="nav-link" href="../../logistics/reports/"><span class="h5" style="color:#f5571c;">|&nbsp;<strong>REPORTS</strong></span></a>
       </li>
    </ul>
 </nav>
 <div style="height:2px; background:#27aae1;"></div>
</div>
<br>