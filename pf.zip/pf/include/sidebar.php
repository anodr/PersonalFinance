 <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../index.php">
        <div class="sidebar-brand-icon">
          <i class="fas fa-school"></i>
        </div>
		
        <div class="sidebar-brand-text mx-3">MySchool</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="../index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Basics
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-users"></i>
          <span title="Students registration">Students</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../students/admission.php">Student Admission</a>
			<a class="collapse-item" href="../students/viewstudents.php">View Students</a>
			<a class="collapse-item" href="../students/attendance.php">Attendance</a>
			<a class="collapse-item" href="../students/attendancereport.php">Attendance Report</a>
			<a class="collapse-item" href="../students/transferclass.php">Transfer Class</a>
          </div>
        </div>
      </li>
	  
	  <!-- Divider -->
      <hr class="sidebar-divider">
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
          <i class="far fa-credit-card"></i>
          <span title="Sell Products here">Fees (Cashier)</span>
        </a>
        <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../fees/pay.php">Fee Payment </a>
            <a class="collapse-item" href="../fees/due.php">Fees Due</a>
			<a class="collapse-item" href="../fees/paid.php">Paid List</a>
            <a class="collapse-item" href="../fees/onlinepay.php">Online Fee Payment</a>			
          </div>
        </div>
      </li>

      <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-graduation-cap"></i>
          <span title="Enter Academics">Academics</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../academics/classes.php">Classes</a>
			<a class="collapse-item" href="../academics/subjects.php">Subjects</a>
			<a class="collapse-item" href="../academics/tests.php">Tests</a>
			<a class="collapse-item" href="../academics/testresults.php">Test Results</a>
			<a class="collapse-item" href="../academics/exams.php">Exams</a>
            <a class="collapse-item" href="../academics/examresults.php">Exam Results</a>				
			<a class="collapse-item" href="../academics/timetable.php">Time Table</a>
			<a class="collapse-item" href="../academics/notes.php">Notes</a>
			<a class="collapse-item" href="../academics/quiz.php">Quizzes</a>
			<a class="collapse-item" href="../academics/lessons.php">Lesson Planning</a>
			<a class="collapse-item" href="../academics/classteacher.php">Class teacher allocation</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTheatre" aria-expanded="true" aria-controls="collapseTheatre">
          <i class="fas fa-laptop"></i>
          <span title="Enter Bought Products">Front Office</span>
        </a>
        <div id="collapseTheatre" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../reception/calls.php">Call & Follow-up</a>
			<a class="collapse-item" href="../reception/inquiry.php">Inquiry</a>
			<a class="collapse-item" href="../reception/complaints.php">Complaints</a>
			<a class="collapse-item" href="../reception/visitors.php">Visitors</a>
			<a class="collapse-item" href="../reception/latearrivals.php">Students Late arrival</a>
			<a class="collapse-item" href="../reception/earlydepartures.php">Students Early Departure</a>
          </div>
        </div>
      </li>
	  
	  <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        <span title="View Students">Students</span>
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseDebtors" aria-expanded="true" aria-controls="collapseDebtors">
          <i class="fas fa-bus"></i>
          <span>Transport</span>
        </a>
        <div id="collapseDebtors" class="collapse" aria-labelledby="headingDebtors" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../transport/routes.php">Routes</a>
			<a class="collapse-item" href="../transport/transportfees.php">Transport Fees</a>
			<a class="collapse-item" href="../transport/destinations.php">Students' Destinations</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCreditors" aria-expanded="true" aria-controls="collapseCreditors">
          <i class="fas fa-hotel"></i>
          <span>Hostel</span>
        </a>
        <div id="collapseCreditors" class="collapse" aria-labelledby="headingCreditors" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../hostels/hostel.php">Hostels</a>
			<a class="collapse-item" href="../hostels/allocation.php">Hostels Allocation</a>
			<a class="collapse-item" href="../hostels/hostelfees.php">Hostel Fees</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseInpatients" aria-expanded="true" aria-controls="collapseInpatients">
          <i class="fas fa-book"></i>
          <span>Library</span>
        </a>
        <div id="collapseInpatients" class="collapse" aria-labelledby="headingInpatients" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../library/library.php">Libraries</a>
			<a class="collapse-item" href="../library/lent.php">Books Lent</a>
			<a class="collapse-item" href="../library/returned.php">Books Returned</a>
			<a class="collapse-item" href="../library/reports.php">Reports</a>
          </div>
        </div>
      </li>
	  	  
      <!-- Divider -->
      <hr class="sidebar-divider">
	  
	  <!-- Heading -->
      <div class="sidebar-heading">
        <span title="View Students">ADMINISTRATION & 
		FINANCE</span>
      </div>
	  
	   <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLabs" aria-expanded="true" aria-controls="collapseLabs">
          <i class="fas fa-user-tie"></i>
          <span>HR & Payroll</span>
        </a>
        <div id="collapseLabs" class="collapse" aria-labelledby="headingLabs" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../hr/staff.php">Employees</a>
			<a class="collapse-item" href="../hr/departments.php">Departments</a>
			<a class="collapse-item" href="../hr/leaves.php">Leave applications</a>
			<a class="collapse-item" href="../hr/projects.php">Projects</a>
			<a class="collapse-item" href="../hr/loans.php">Loans</a>
			<a class="collapse-item" href="../hr/assets.php">Assets</a>
			<a class="collapse-item" href="../hr/payroll.php">Payroll</a>
			<a class="collapse-item" href="../hr/board.php">Notice Board</a>
			<a class="collapse-item" href="../hr/reports.php">Reports</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePharmacy" aria-expanded="true" aria-controls="collapsePharmacy">
          <i class="fas fa-chart-bar"></i>
          <span>Accounting / Finance</span>
        </a>
        <div id="collapsePharmacy" class="collapse" aria-labelledby="headingPharmacy" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../finance/bankaccounts.php">School Accounts</a>
			<a class="collapse-item" href="../finance/expenses.php">Expenses</a>
			<a class="collapse-item" href="../finance/income.php">Income</a>
			<a class="collapse-item" href="../finance/daybook.php">Day Book</a>
			<a class="collapse-item" href="../finance/cashbook.php">Cash Book</a>
			<a class="collapse-item" href="../finance/bankbook.php">Bank Book</a>
			<a class="collapse-item" href="../finance/reports.php">Reports</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseX-Ray" aria-expanded="true" aria-controls="collapseX-Ray">
          <i class="fas fa-boxes"></i>
          <span>Store Management</span>
        </a>
        <div id="collapseX-Ray" class="collapse" aria-labelledby="headingX-Ray" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../store/suppliers.php">Suppliers</a>			
			<a class="collapse-item" href="../store/purchase.php">Purchase</a>
			<a class="collapse-item" href="../store/consumed.php">Consumed/Used</a>
			<a class="collapse-item" href="../store/inventoryreport.php">Inventory</a>
			<a class="collapse-item" href="../store/issued.php">Goods Issued</a>
			<a class="collapse-item" href="../store/report.php">Reports</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFleet" aria-expanded="true" aria-controls="collapseFleet">
          <i class="fas fa-gas-pump"></i>
          <span>Fleet Management</span>
        </a>
        <div id="collapseFleet" class="collapse" aria-labelledby="headingFleet" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../fleet/fuel.php">Fuel</a>			
			<a class="collapse-item" href="../fleet/service.php">Fleet Service</a>
			<a class="collapse-item" href="../fleet/spare.php">Spare Parts</a>
			<a class="collapse-item" href="../fleet/drivers.php">Drivers & Salary</a>
			<a class="collapse-item" href="../fleet/report.php">Reports</a>
			<a class="collapse-item" href="../fleet/dashboard.php">Dashboard</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseClinicalservices" aria-expanded="true" aria-controls="collapseClinicalservices">
          <i class="fas fa-folder-open"></i>
          <span>Reports</span>
        </a>
        <div id="collapseClinicalservices" class="collapse" aria-labelledby="headingClinicalservices" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../reports/studentsreport.php">Students Reports</a>
			<a class="collapse-item" href="../reports/feesduereport.php">Fees Due Report</a>
			<a class="collapse-item" href="../reports/feespaidreport.php">Fees Paid Report</a>
			<a class="collapse-item" href="../reports/absentees.php">Absentees Report</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseDispensing" aria-expanded="true" aria-controls="collapseDispensing">
          <i class="fas fa-cogs"></i>
          <span>Settings</span>
        </a>
        <div id="collapseDispensing" class="collapse" aria-labelledby="headingDispensing" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="../settings/institution.php">Institution Details</a>
			<a class="collapse-item" href="../settings/academic.php">Academic Details</a>
			<a class="collapse-item" href="../settings/importstudents.php">Students Import</a>
			<a class="collapse-item" href="../settings/users.php">System Users</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->