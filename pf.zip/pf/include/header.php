<?php ob_start(); ?>
<?php //session_start(); ?>
<?php //require_once("../include/DB.php"); ?>
<?php //require_once("../include/sessions.php"); ?> 
<?php require_once("functions.php"); ?>
<?php //Confirm_Login(); ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <title>MySchool - School Information Management Software</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="apple-touch-icon" sizes="180x180" href="../favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../favicon/favicon-16x16.png">
<link rel="shortcut icon" href="../favicon/favicon.ico">
<link rel="manifest" href="../favicon/site.webmanifest">
<link rel="mask-icon" href="../favicon/safari-pinned-tab.svg" color="#5bbad5">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">
  
  <!-- You can use Open Graph tags to customize link previews.
    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->
  <meta property="fb:app_id"        content="161336481463790"/> 
  <meta property="og:url"           content="http://econneckt.com/ezpos" /> 
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="EZPOS-Point of Sale and Inventory Management System" />
  <meta property="og:description"   content="EZPOS-Point of Sale and Inventory Management System" />
  <meta property="og:image"         content="http://econneckt.com/images/epos.jpg" />
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="elinc/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
  <link rel="stylesheet" href="font-awesome-animation.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/js/gijgo.min.js" type="text/javascript"></script>
  <link href="https://cdn.jsdelivr.net/npm/gijgo@1.9.6/css/gijgo.min.css" rel="stylesheet" type="text/css" />
  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.2.23/angular.min.js"></script>
  <script src="http://code.jquery.com/jquery-1.4.3.min.js"></script>
  
        <!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.8/css/mdb.min.css" rel="stylesheet">

<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.8/js/mdb.min.js"></script>

<!-- MDBootstrap Cards Extended Pro  -->
<link href="css/addons-pro/cards-extended.min.css" rel="stylesheet">
  
  
  <style>
  .description{
	color:#566573;
   margin-top:1px;
  }
  a:link{
  color:#115587;
  text-decoration:none;
  }
  
a:hover{
  text-decoration:none;
  color:#0C7C2B;
  }
  
  .vl {
    border-left: 2px solid gray;
    height: 25rem;
}
  

.videowrapper {
    float: none;
    clear: both;
    width: 100%;
    position: relative;
    padding-bottom: 56.25%;
    padding-top: 25px;
    height: 0;
}
.videowrapper iframe {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

body{
    padding-left:;
	padding-right:;
	padding-bottom:2rem;
	padding-top:1rem;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: #FFD700;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

/* adds some margin below the link sets  */
.navbar .dropdown-menu div[class*="col"] {
   margin-bottom:1rem;
}

.custom-toggler.navbar-toggler {
    border-color: rgb(0,0,0);
}
.custom-toggler .navbar-toggler-icon {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 32 32' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba(0,0,0, 0.7)' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 8h24M4 16h24M4 24h24'/%3E%3C/svg%3E");
}

.navbar .dropdown-menu {
  border:none;
  background-color:rgba(0, 0, 0, 0.7)!important;
}

/* breakpoint and up - mega dropdown styles */
@media screen and (min-width: 992px) {
  
  /* remove the padding from the navbar so the dropdown hover state is not broken */
.navbar {
  padding-top:0px;
  padding-bottom:0px;
}

/* remove the padding from the nav-item and add some margin to give some breathing room on hovers */
.navbar .nav-item {
  padding:.5rem .5rem;
  margin:0 .25rem;
}

/* makes the dropdown full width  */
.navbar .dropdown {position:static;}

.navbar .dropdown-menu {
  width:100%;
  left:0;
  right:0;
/*  height of nav-item  */
  top:45px;
}
  
  /* shows the dropdown menu on hover */
.navbar .dropdown:hover .dropdown-menu, .navbar .dropdown .dropdown-menu:hover {
  display:block!important;
}
  
  .navbar .dropdown-menu {
    border: 1px solid rgba(0,0,0,.15);
    background-color: #fff;
  }

}

.gold {
  background-color:#FFD700;
}


body {
    font-family: Arial,Verdana,sans-serif !important;
	font-size: 15.1px;
    line-height: 19px;
    margin: 1em 0;	
}

 </style>
  
</head>

<body onload="startTime()">
<div class="container-fluid">
  <div class="row">
   <div class="col-md-4">
    <a class="navbar-brand" href="http://econneckt.com"><h5>ECONNECKT TECHNOLOGIES</h5></a>
   </div><br>

<div class="col-md-4"></div><br>
   
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
  <div class="pull-right">
    <a class="" href="#" >
      <?php 
		     if(isset($_SESSION['username'])){
		        echo $_SESSION['username']; 
				echo "&nbsp;"; 
                echo   "<a class='btn aqua-gradient btn-sm' href='../register/logout.php'>Logout</a>";
			 }else{
				 echo "<a href='../register/login.php'>Login</a>";
			 }
	  ?>
    </a>
  </div>
</div>
</div>

<nav class="navbar navbar-expand-lg navbar-custom" style="background-color:#4169E1; color:white;">
  <a class="navbar-brand h6" href="http://econneckt.com/ezpos" style="color:white;"><span class="h6 strong" style="color:white;"><i class="fas fa-chart-line"></i>&nbsp;<strong>EZPOS - ACCOUNTING SOFTWARE</strong></span></a>
  <button class="navbar-toggler custom-toggler" type="button" style="color:black;" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon icon" style="color:black;"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto" style="background-color:black;">
       <li class="nav-item">
         <a class="nav-link" href="http://econneckt.com/ezpos/soldproducts/"><span class="h6 strong" style="color:white;">SOLD</span></a>
       </li>
	    <li class="nav-item">
         <a class="nav-link" href="http://econneckt.com/ezpos/boughtproducts/"><span class="h6" style="color:white;">BOUGHT</span></a>
       </li>
	    <li class="nav-item">
        <a class="nav-link" href="http://econneckt.com/ezpos/customers/"><span class="h6" style="color:white;">SELL</span></a>
       </li>
	   <li class="nav-item">
         <a class="nav-link" href="http://econneckt.com/ezpos/suppliers/"><span class="h6" style="color:white;">BUY</span></a>
       </li>
	   <li class="nav-item">
         <a class="nav-link" href="http://econneckt.com/ezpos/transactions/"><span class="h6" style="color:white;">TRANSACTIONS</span></a>
       </li>
       <li class="nav-item">
         <a class="nav-link" href="http://econneckt.com/ezpos/reports/"><span class="h6" style="color:white;">REPORTS</span></a>
       </li>
       <li class="nav-item">
        <a class="nav-link" style="color:white;" href="http://econneckt.com/contacts/">CONTACT US</a>
      </li>
    </ul>
  </div>

</nav>


</div>
<br>

</body>