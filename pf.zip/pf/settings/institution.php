<?php require('../include/basic.php');?>

<div class="container-fluid">

 <div><?php 
         if(isset($_SESSION['SuccessMessage'])){
		   echo SuccessMessage();
		   unset($_SESSION["SuccessMessage"]);
		}
	 ?>
 </div>

  <h2 class="text-center blue-text">Institution Details</h2>
   <hr>

 <div class="row">

<div class="col-md-8"> 

<div class="card"> 
 <div class="card-body"><br> 

<form action="add_institution.php" method="POST" enctype="multipart/form-data" autocomplete="off">

<div class="table-responsive">
  <table class="table table-hover table-sm">
	<tr>
     <td>
      <label for="quantity">Institution Name:</label>
     </td>
     <td>
      <input type="text" class="form-control" name="institution" placeholder="Institution Name" REQUIRED>
     </td>
    </tr>
	
	
	<tr>
     <td>
      <label for="quantity">Address:</label>
     </td>
     <td>
      <input type="text" class="form-control" name="address" id="imageselect">
     </td>
    </tr>
	<tr>
     <td>
      <label for="quantity">Location:</label>
     </td>
     <td>
      <input type="text" class="form-control" name="location" id="imageselect">
     </td>
    </tr>
	<tr>
     <td>
      <label for="quantity">Motto:</label>
     </td>
     <td>
      <input type="text" class="form-control" name="motto" id="imageselect">
     </td>
    </tr>
	<tr>
      <td>
       <label for="price">Notes:</label>
      </td>
      <td>
       <textarea class="form-control" name="notes" id="notes" ></textarea>
      </td>
    </tr>
	<tr>
     <td>
      <label for="product">Logo:</label>
     </td>
     <td>      
	  <input type="File" class="form-control" name="file" id="imageselect" required>
	 </td>
    </tr>
 </table>
</div> 
    <input type="Submit" class="btn btn-sm btn-primary btn-block" id="btnAddProduct" value="SAVE" >
</form>

</div>
</div><br>
</div>

 </div>
 
  <?php
           try{
              require_once('../include/DB.php');
			  
			  if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }
              	  
              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $stmt = $conn->prepare("SELECT * FROM institution WHERE institutionby='$ID' 
			                          ORDER BY dateinstitution DESC LIMIT 1 ");
              $stmt->execute();
	          $SrNo=0;

              $stmt->bindColumn('institution_id', $Id);
              $stmt->bindColumn('institution', $institution);
			  $stmt->bindColumn('address', $address);
			  $stmt->bindColumn('location', $location);
			  $stmt->bindColumn('motto', $motto);
			  $stmt->bindColumn('notes', $notes);
			  $stmt->bindColumn('file', $File);			  
			  $stmt->bindColumn('dateinstitution', $DateTime);

              $errorInfo = $conn->errorInfo();
              //print_r($errorInfo);
              if (isset($errorInfo[2])) {
   	          $error = $errorInfo[2];
                   }
                 }catch(Exception $e){
	          $error = $e->getMessage();
                 }
              if(isset($error)){echo "Errors : ". $error;}
			  while ($row = $stmt->fetch()) {
              $SrNo++;
	             ?>
  <h2 class="text-center blue-text">
    <?php
	if($File == ""){
		echo 1;
	}else{
		echo "<img src='resize/$File'  alt='$institution' class='img-fluid thumbnail' style='width:15%; '>";
	}
	?>
	
	 <?php echo htmlentities($institution); ?></h2>
   <hr>
   <div class="card shadow mb-4">
    <div class="card-body">
	 <b>Address:</b> &nbsp;&nbsp; <?php echo htmlentities($address); ?><br>
	 <b>Location:</b> &nbsp;&nbsp;  <?php echo htmlentities($location); ?><br>
     <b>Motto:</b> &nbsp;&nbsp;  <?php echo htmlentities($motto); ?><hr>
	 <b style="color:#36b9cc;">Notes: &nbsp;&nbsp;  <?php echo htmlentities($notes); ?></b><br>
    </div>
   </div>
   
			  <?php } ?>

</div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Econneckt Technologies &copy <?php echo date('Y'); ?></span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="../simplelogin/logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="../vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="../js/demo/datatables-demo.js"></script>

</body>

</html>
