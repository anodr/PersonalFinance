<?php ob_start();
session_start(); ?>
<?php
try{
   require_once('../include/DB.php');
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
   if(isset($_POST) & !empty($_POST)){
   $CurrentTime=time();
   date_default_timezone_set('Africa/Dar_es_Salaam');
   $DateTime=strftime('%Y-%m-%d %H:%M:%S',$CurrentTime);
   if(isset($_SESSION['login'])){
		  $Admin = $_SESSION['id'];
		}
   
   $sql = "INSERT INTO staffall(staffname,staffpay,stafflocation,staffphone,datestaff,staffby)
	       VALUES(:staffname, :staffpay, :stafflocation, :staffphone, :datestaff, :staffby)";
   $result = $conn->prepare($sql);
   $result->bindParam(':staffname', htmlspecialchars($_POST['staffname']),PDO::PARAM_STR);
   $result->bindParam(':staffpay', htmlspecialchars($_POST['staffpay']),PDO::PARAM_INT);
   $result->bindParam(':stafflocation', htmlspecialchars($_POST['stafflocation']),PDO::PARAM_STR);
   $result->bindParam(':staffphone', htmlspecialchars($_POST['staffphone']),PDO::PARAM_INT);
   $result->bindParam(':datestaff', htmlspecialchars($DateTime),PDO::PARAM_STR);
   $result->bindParam(':staffby', htmlspecialchars($Admin),PDO::PARAM_STR);
   $res = $result->execute();

  if($res){
  $_SESSION["SuccessMessage"]="Staff Added Successfully";
  header('Location: ' . $_SERVER['HTTP_REFERER']);
  }else{
  $_SESSION["ErrorMessage"]="Something went wrong. Try again";
  header("Location: index.php");
  }
   
}
}catch(Exception $e){
	$error = $e->getMessage();

}
if(isset($error)){echo "Errors : ". $error;}
	var_dump($res);

	//echo $result . " Records Inserted in DB" .$db->lastInsertID();
?>
	
	
	