<?php ob_start();
session_start();
 ?>
<?php
try{
   require_once('../include/DB.php');
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

   require_once("vendor/autoload.php");
 
   \Tinify\setKey("TINYPNG_API_KEY");
 
   if(isset($_POST) & !empty($_POST)){
   $CurrentTime=time();
   date_default_timezone_set('Africa/Dar_es_Salaam');
   $DateTime=strftime('%Y-%m-%d %H:%M:%S',$CurrentTime);
   if(isset($_SESSION['login'])){
		  $Admin = $_SESSION['id'];
		}

require_once("vendor/autoload.php");
 
\Tinify\setKey("ZF1lWqkz4R53wcbjQ9JNTWZSVLXMLhkq"); //pass your actual API key
 
if(isset($_POST) & !empty($_POST)){
 
    $supported_image = array('image/gif', 'image/jpg', 'image/jpeg', 'image/png');
 
    if (in_array($_FILES['file']['type'], $supported_image)) {
 
        $src_file_name = $_FILES['file']['name'];
 
        if (!file_exists(getcwd().'/uploads')) {
 
            mkdir(getcwd().'/uploads', 0777);
        }
 
        move_uploaded_file($_FILES['file']['tmp_name'], getcwd().'/uploads/'.$_FILES['file']['name']);
		$orgfile='uploads/'.$_FILES['file']['name'];
 
        //optimize image using TinyPNG
        $source = \Tinify\fromFile(getcwd().'/uploads/'.$_FILES['file']['name']);
        $source->toFile(getcwd().'/resize/'.$_FILES['file']['name']);
		
		$resized = $source->resize(array(
          "method" => "fit",
          "width" => 1000,
          "height" => 720
          ));
        $resized->toFile(getcwd().'/resize/'.$_FILES['file']['name']);
        
		unlink($orgfile);
   
   $sql = "INSERT INTO institution(institution,address,location,motto,notes,file,dateinstitution,institutionby)
	       VALUES(:institution, :address, :location, :motto, :notes, :File,  :dateinstitution, :institutionby)";
   $result = $conn->prepare($sql);
   $result->bindParam(':institution', htmlspecialchars($_POST['institution']),PDO::PARAM_STR);
   $result->bindParam(':address', htmlspecialchars($_POST['address']),PDO::PARAM_STR);
   $result->bindParam(':location', htmlspecialchars($_POST['location']),PDO::PARAM_STR);
   $result->bindParam(':motto', htmlspecialchars($_POST['motto']),PDO::PARAM_STR);
   $result->bindParam(':notes', htmlspecialchars($_POST['notes']),PDO::PARAM_STR);
   $result->bindParam(':File', htmlspecialchars($_FILES['file']['name']),PDO::PARAM_STR);
   $result->bindParam(':dateinstitution', htmlspecialchars($DateTime),PDO::PARAM_STR);
   $result->bindParam(':institutionby', htmlspecialchars($Admin),PDO::PARAM_STR);
   $res = $result->execute();
   
   

  if($res){
  $_SESSION["SuccessMessage"]="Institution Added Successfully";
  header('Location: ' . $_SERVER['HTTP_REFERER']);
  }else{
  $_SESSION["ErrorMessage"]="Something went wrong. Try again";
  header("Location: index.php");
  }
   
}}}
}catch(Exception $e){
	$error = $e->getMessage();

}
if(isset($error)){echo "Errors : ". $error;}
	var_dump($res);

	//echo $result . " Records Inserted in DB" .$db->lastInsertID();
	
	
	
	
	
	