<?php require('../include/basic.php');?>

<div class="container-fluid">

 <div><?php 
         if(isset($_SESSION['SuccessMessage'])){
		   echo SuccessMessage();
		   unset($_SESSION["SuccessMessage"]);
		}
	 ?>
 </div>

  <h2 class="text-center blue-text">Expenses</h2>
   <hr>
		  
   <div class="row">  
     <div class="col-md-6">
	 
	 
      <?php
	      //product modal
	       include_once("modal/suppliermodal.php");
	   ?>
	   <?php
	      //product modal
	       include_once("modal/expensesmodal.php");
	      ?> 
 </div>
</div>
 

 <div class="row">

<div class="col-md-8">  

<div class="card">
 <div class="card-body">
     
     <div class="row">
	  <div class="col-md-6">
	    <small><a href="" data-toggle="modal" data-target="#mySupplier">Add Supplier</a></small>	 
	  </div>
	  <div class="col-md-6">
	    <small><a href="" data-toggle="modal" data-target="#myExpenses">Add Expense Name</a></small> 	 
	  </div>
	 </div><br>
     
<form action="add_expenses.php" method="POST" enctype="multipart/form-data" autocomplete="off">

<div class="table-responsive">
  <table class="table table-hover table-sm">
    <tr>
     <td>
      <label for="product">Expense:</label>
     </td>
     <td>      
	  <select class="form-control" id="expensename" name="expensename">	 
		 <?php
           try{
              require_once('../include/DB.php');
			  
			  if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }

              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $stmt = $conn->prepare("SELECT * FROM expensecat WHERE expensecatby='$ID' ORDER BY expensecatname ASC");
              $stmt->execute();
	          $SrNo=0;

              $stmt->bindColumn('expensecat_id', $Id);
              $stmt->bindColumn('expensecatname', $expensecatname);

              $errorInfo = $conn->errorInfo();
              print_r($errorInfo);
              if (isset($errorInfo[2])) {
   	          $error = $errorInfo[2];
                   }
                 }catch(Exception $e){
	          $error = $e->getMessage();
                 }
              if(isset($error)){echo "Errors : ". $error;}
			  echo '<option value="">Choose...</option>';
			  while ($row = $stmt->fetch()) {
              $SrNo++;
	             ?>
		        <option REQUIRED><?php echo htmlentities($expensecatname); ?></option>
		           <?php } ?>
		        <?php
				   echo "<option value='<a href='' data-toggle='modal' data-target='#myExpenses' style='border-bottom: 1px dotted #000;'>";
				   echo "Oh . . Add Expenses Name";
				   echo "</a>";			 
				   echo "</option>"; 
				 ?>     
		  </select>
	 </td>
    </tr>
	<tr>
     <td>
      <label for="product">Supplier:</label>
     </td>
     <td>      
	  <select class="form-control" id="expensesupplier" name="expensesupplier">	 
		 <?php
           try{
              require_once('../include/DB.php');
			  
			  if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }

              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $stmt = $conn->prepare("SELECT * FROM suppliers WHERE supplierby='$ID' ORDER BY suppliername ASC");
              $stmt->execute();
	          $SrNo=0;

              $stmt->bindColumn('supplier_id', $Id);
              $stmt->bindColumn('suppliername', $suppliername);

              $errorInfo = $conn->errorInfo();
              print_r($errorInfo);
              if (isset($errorInfo[2])) {
   	          $error = $errorInfo[2];
                   }
                 }catch(Exception $e){
	          $error = $e->getMessage();
                 }
              if(isset($error)){echo "Errors : ". $error;}
			  echo '<option value="">Choose...</option>';
			  while ($row = $stmt->fetch()) {
              $SrNo++;
	             ?>
		        <option><?php echo htmlentities($suppliername); ?></option>
		           <?php } ?>
		        <?php
				   echo "<option value='<a href='' data-toggle='modal' data-target='#mySupplier' style='border-bottom: 1px dotted #000;'>";
				   echo "Oh . . Add Supplier";
				   echo "</a>";			 
				   echo "</option>"; 
				 ?>      
		  </select>
	 </td>
    </tr>
    <tr>
     <td>
      <label for="quantity">Amount:</label>
     </td>
     <td>
      <input type="number" id="quantity" name="expenseamount" class="form-control" required>
     </td>
    </tr>
 </table>
</div> 
    <input type="Submit" class="btn btn-sm btn-primary btn-block" id="btnAddProduct" value="Add Expenses" >
</form>

</div>
</div>


<hr>

</div>

 </div>

 <h1 class="h3 mb-2 text-gray-800 text-center">Expenses Amount</h1><br> 

  <div class="card shadow mb-4">
    <div class="card-header py-3">
              
	<?php
    require_once('../include/DB.php');
   
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }
   
    $res1 = $conn->prepare("SELECT SUM(expenseamount) as Amount FROM expenses WHERE addedexpense='$ID'");
    $res1->execute();
	$row = $res1->fetch(PDO::FETCH_ASSOC);
	
	echo "<h6>";
	  echo 'Expenses Amount:&nbsp;';  echo "<span class='pull-right'>".number_format($row['Amount'])."</span>";
	echo "</h6>";
    ?>			
  </div>

<div class="card-body">
 <div class="table-responsive">
  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
   <thead>
    <tr>
      <th>No.</th>
      <th>Expense</th>
	  <th>Supplier</th>
	  <th>Amount</th>
	  <th>Date</th>
	  <th></th>
    </tr>
   </thead>
   <tbody>
   <?php
         try{
              require_once('../include/DB.php');

              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			  $stmt = $conn->prepare("SELECT * FROM expenses WHERE addedexpense='$ID' ORDER BY dateexpense DESC");		  
              $stmt->execute();
	          $SrNo=0;
              $stmt->bindColumn('expense_id', $Id);
			  $stmt->bindColumn('expensename', $expensename);
			  $stmt->bindColumn('expensesupplier', $expensesupplier);
              $stmt->bindColumn('expenseamount', $expenseamount);
			  $stmt->bindColumn('dateexpense', $DateTime);

              $errorInfo = $conn->errorInfo();
              //print_r($errorInfo);
              if (isset($errorInfo[2])) {
   	          $error = $errorInfo[2];
                   }
                 }catch(Exception $e){
	          $error = $e->getMessage();
                 }
              if(isset($error)){echo "Errors : ". $error;}
              while ($row = $stmt->fetch()) {
              $SrNo++;
	             ?>		  
  <tr>
    <td><?php echo $SrNo; ?></td>
	<td><?php echo $expensename; ?></td>
	<td><?php echo ($expensesupplier); ?></td>
	<td><?php echo number_format($expenseamount); ?></td>
	<td><?php echo ($DateTime); ?></td>
	<td><a href="delete_expense.php?id=<?php echo $Id; ?>"><i class="fas fa-trash" style="color:gray;"></i></a></td>
  </tr>
 <?php } ?>				
  </tbody>
  </table>
  </div>
  </div>
  </div>

</div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Econneckt Technologies &copy <?php echo date('Y'); ?></span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="../simplelogin/logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="../vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="../vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="../js/demo/datatables-demo.js"></script>

</body>

</html>
