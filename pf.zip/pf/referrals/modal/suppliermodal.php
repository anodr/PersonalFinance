<!-- The Modal -->
  <div class="modal fade" id="mySupplier">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
	   <div class="modal-header">
        <h5 class="modal-title text-center" id="exampleModalLabel">Add New Supplier</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
	
	
	<!-- Modal body -->
   <div class="modal-body">
	  <form action="add_supplier.php" method="POST" enctype="multipart/form-data" autocomplete="off">

	   
  <div class="form-group row input-group mb-3">
    <!-- Material input -->
    <label for="inputEmail3MD" class="col-sm-4 offset-1 col-form-label">* Supplier Name:</label>
    <div class="col-sm-7">
      <div class="md-form mt-0">
        <input type="text" class="form-control" id="inputEmail3MD" placeholder="Enter Name" name="suppliername" REQUIRED>
      </div>
    </div>
  </div>
  
  <div class="form-group row input-group mb-3">
    <!-- Material input -->
    <label for="inputEmail3MD" class="col-sm-4 offset-1 col-form-label">Location:</label>
    <div class="col-sm-7">
      <div class="md-form mt-0">
        <input type="text" class="form-control" id="inputEmail3MD" placeholder="Location" name="location">
      </div>
    </div>
  </div>
  
  <div class="form-group row input-group mb-3">
    <!-- Material input -->
    <label for="inputEmail3MD" class="col-sm-4 offset-1 col-form-label">Phone/Tel:</label>
    <div class="col-sm-7">
      <div class="md-form mt-0">
        <input type="text" class="form-control" id="inputEmail3MD" placeholder="Phone" name="phone">
      </div>
    </div>
  </div>

	
 </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
		  <div class="form-group">
		    <input class="btn btn-warning" type="button" data-dismiss="modal" value="Close" >
		    <input class="btn btn-success" type="Submit" name="Submit" value=" Save"> 
		   </div>
        </div>
		</form>
        
      </div>
    </div>
  </div>