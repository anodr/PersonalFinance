<!-- The Modal -->
  <div class="modal fade" id="myExpenses">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
	   <div class="modal-header">
        <h5 class="modal-title text-center" id="exampleModalLabel">Add Expense Name</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
	
	
	<!-- Modal body -->
   <div class="modal-body">
	  <form action="add_expensecat.php" method="POST" enctype="multipart/form-data" autocomplete="off">

	   
  <div class="form-group row input-group mb-3">
    <!-- Material input -->
    <label for="inputEmail3MD" class="col-sm-4 offset-1 col-form-label">* Expense Name:</label>
    <div class="col-sm-7">
      <div class="md-form mt-0">
        <input type="text" class="form-control" id="inputEmail3MD" placeholder="Expense Name" name="expensecatname" REQUIRED>
      </div>
    </div>
  </div>
	
 </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
		  <div class="form-group">
		    <input class="btn btn-warning" type="button" data-dismiss="modal" value="Close" >
		    <input class="btn btn-success" type="Submit" name="Submit" value=" Save"> 
		   </div>
        </div>
		</form>
        
      </div>
    </div>
  </div>