<?php ob_start();
session_start(); ?>
<?php
try{
   require_once('../include/DB.php');
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
   if(isset($_POST) & !empty($_POST)){
   $CurrentTime=time();
   date_default_timezone_set('Africa/Dar_es_Salaam');
   $DateTime=strftime('%Y-%m-%d %H:%M:%S',$CurrentTime);
   if(isset($_SESSION['login'])){
		  $Admin = $_SESSION['id'];
		}
   
   $sql = "INSERT INTO suppliers(suppliername,location,phone,datesupplier,supplierby)
	       VALUES(:suppliername, :location, :phone, :datesupplier, :supplierby)";
   $result = $conn->prepare($sql);
   $result->bindParam(':suppliername', htmlspecialchars($_POST['suppliername']),PDO::PARAM_STR);
   $result->bindParam(':location', htmlspecialchars($_POST['location']),PDO::PARAM_STR);
   $result->bindParam(':phone', htmlspecialchars($_POST['phone']),PDO::PARAM_INT);
   $result->bindParam(':datesupplier', htmlspecialchars($DateTime),PDO::PARAM_STR);
   $result->bindParam(':supplierby', htmlspecialchars($Admin),PDO::PARAM_STR);
   $res = $result->execute();

  if($res){
  $_SESSION["SuccessMessage"]="Supplier Added Successfully";
  header("Location: purchase.php");
  }else{
  $_SESSION["ErrorMessage"]="Something went wrong. Try again";
  header("Location: index.php");
  }
   
}
}catch(Exception $e){
	$error = $e->getMessage();

}
if(isset($error)){echo "Errors : ". $error;}
	var_dump($res);

	//echo $result . " Records Inserted in DB" .$db->lastInsertID();
?>
	
	
	