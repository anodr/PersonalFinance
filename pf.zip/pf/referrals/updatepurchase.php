<?php require('../include/basic.php');?>


<?php

// php update data in mysql database using PDO

if(isset($_POST['Submit']))
{
    try {
        require_once('../include/DB.php');
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $exc) {
        echo $exc->getMessage();
        exit();
    }
    
    // get values form input text and number
    
    $productsbought_id  = htmlspecialchars($_POST['productsbought_id']);
    $productbought= htmlspecialchars($_POST['productbought']);
    $supplier = htmlspecialchars($_POST['supplier']);
    $quantitybought  = htmlspecialchars($_POST['quantitybought']);
	$pricebought  = htmlspecialchars($_POST['pricebought']);
	$paid  = htmlspecialchars($_POST['paid']);
    
    // mysql query to Update data
	
	$PostIDFromURL=$_GET['id'];
    
    $query = "UPDATE `productsbought` SET `productbought`=:productbought,`supplier`=:supplier,`quantitybought`=:quantitybought,`pricebought`=:pricebought,`paid`=:paid WHERE `productsbought_id` = $PostIDFromURL ";
    
    $pdoResult = $conn->prepare($query);
    
    $pdoExec = $pdoResult->execute(array(":productbought"=>$productbought,":supplier"=>$supplier,":quantitybought"=>$quantitybought,":pricebought"=>$pricebought,":paid"=>$paid));
    
    if($pdoExec){
        $_SESSION["SuccessMessage"]="Purchase Updated Successfully";
        header("Location: purchase.php");
    }else{
        echo 'ERROR Data Not Updated';
    }

}

?>


<!-- Begin Page Content -->
<div class="container-fluid">

 <div><?php 
         if(isset($_SESSION['SuccessMessage'])){
		   echo SuccessMessage();
		   unset($_SESSION["SuccessMessage"]);
		}
	 ?>
 </div>

 <h2 class="text-center blue-text">Update Purchase</h2>
   <hr>
	   

<!-- Content Row -->
 <div class="row">

<div class="col-md-12">

 <div class="card">
  <div class="card-body">
  
   <?php
         try{
              require_once('../include/DB.php');

              $PostIDFromURL=$_GET['id'];
			  
              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			  $stmt = $conn->prepare("SELECT * FROM productsbought WHERE addedbuy='$ID' AND productsbought_id='$PostIDFromURL' ");		  
              $stmt->execute();
	          $SrNo=0;
              $stmt->bindColumn('productsbought_id', $Id);
			  $stmt->bindColumn('productbought', $productbought);
			  $stmt->bindColumn('supplier', $supplier);
              $stmt->bindColumn('quantitybought', $quantitybought);
			  $stmt->bindColumn('pricebought', $pricebought);
			  $stmt->bindColumn('paid', $paid);
			  $stmt->bindColumn('datebuy', $DateTime);

              $errorInfo = $conn->errorInfo();
              //print_r($errorInfo);
              if (isset($errorInfo[2])) {
   	          $error = $errorInfo[2];
                   }
                 }catch(Exception $e){
	          $error = $e->getMessage();
                 }
              if(isset($error)){echo "Errors : ". $error;}
              while ($row = $stmt->fetch()) {
              $SrNo++;
	             ?>
   
<form action="updatepurchase.php?id=<?php echo $PostIDFromURL; ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
  
  <div class="form-group row input-group mb-3">
    <!-- Material input -->
    <label for="inputEmail3MD" class="col-sm-4 offset-1 col-form-label">Supplier/Customer:</label>
    <div class="col-sm-7">
      <div class="md-form mt-0">
        <input type="text" class="form-control" value="<?php echo $supplier; ?>" id="inputEmail3MD" placeholder="Supplier Name" name="supplier" READONLY>
      </div>
    </div>
  </div>
  
  <div class="form-group row input-group mb-3">
    <!-- Material input -->
    <label for="inputEmail3MD" class="col-sm-4 offset-1 col-form-label">Product:</label>
    <div class="col-sm-7">
      <div class="md-form mt-0">
        <input type="text" class="form-control" value="<?php echo $productbought; ?>" id="inputEmail3MD" placeholder="product" name="productbought" READONLY>
      </div>
    </div>
  </div>
  
  <div class="form-group row input-group mb-3">
    <!-- Material input -->
    <label for="inputEmail3MD" class="col-sm-4 offset-1 col-form-label">Quantity:</label>
    <div class="col-sm-7">
      <div class="md-form mt-0">
        <input type="number" class="form-control" value="<?php echo $quantitybought; ?>" id="inputEmail3MD" placeholder="Quantity" name="quantitybought">
      </div>
    </div>
  </div>
  
  <div class="form-group row input-group mb-3">
    <!-- Material input -->
    <label for="inputEmail3MD" class="col-sm-4 offset-1 col-form-label">Price/Unit:</label>
    <div class="col-sm-7">
      <div class="md-form mt-0">
        <input type="number" class="form-control" value="<?php echo $pricebought; ?>" id="inputEmail3MD" placeholder="Price/Unit" name="pricebought">
      </div>
    </div>
  </div>
  
  <div class="form-group row input-group mb-3">
    <!-- Material input -->
    <label for="inputEmail3MD" class="col-sm-4 offset-1 col-form-label">Paid:</label>
    <div class="col-sm-7">
      <div class="md-form mt-0">
        <input type="number" class="form-control" value="<?php echo $paid; ?>" id="inputEmail3MD" placeholder="Quantity" name="paid">
      </div>
    </div>
  </div>

<?php } ?>

 <input class="btn btn-success btn-block" type="Submit" name="Submit" value="Update"> 

 </form>
 
  </div>	
 </div>
</div>

 

 </div>

 </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Econneckt Technologies &copy <?php echo date('Y'); ?></span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="../js/sb-admin-2.min.js"></script>
  
  <!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.12.0/js/mdb.min.js"></script>

</body>

</html>
