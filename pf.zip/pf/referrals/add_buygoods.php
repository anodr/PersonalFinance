<?php ob_start(); 
session_start(); 
?>
<?php
try{
   require_once('../include/DB.php');
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
   if(isset($_POST) & !empty($_POST)){
   $CurrentTime=time();
   date_default_timezone_set('Africa/Dar_es_Salaam');
   $DateTime=strftime('%Y-%m-%d %H:%M:%S',$CurrentTime);
   if(isset($_SESSION['login'])){
		  $Admin = $_SESSION['id'];
		}

   $sql = "INSERT INTO productsbought(productbought,supplier,quantitybought,pricebought,paid,datebuy,addedbuy)
	       VALUES(:productbought, :supplier, :quantitybought, :pricebought, :paid, :datebuy, :addedbuy)";
   $result = $conn->prepare($sql); 
   $result->bindParam(':productbought', htmlspecialchars($_POST['productbought']),PDO::PARAM_STR);
   $result->bindParam(':supplier', htmlspecialchars($_POST['supplier']),PDO::PARAM_STR);
   $result->bindParam(':quantitybought', htmlspecialchars($_POST['quantitybought']),PDO::PARAM_INT);
   $result->bindParam(':pricebought', htmlspecialchars($_POST['pricebought']),PDO::PARAM_INT);
   $result->bindParam(':paid', htmlspecialchars($_POST['paid']),PDO::PARAM_INT);
   $result->bindParam(':datebuy', htmlspecialchars($DateTime),PDO::PARAM_STR);
   $result->bindParam(':addedbuy', htmlspecialchars($Admin),PDO::PARAM_STR);
   $res = $result->execute();
  if($res){
  $_SESSION["SuccessMessage"]="Products Bought Successfully";
  header("Location: purchase.php");
  }else{
  $_SESSION["ErrorMessage"]="Something went wrong. Try again";
  header("Location: index.php");
  }
   
}
}catch(Exception $e){
	$error = $e->getMessage();

}
if(isset($error)){echo "Errors : ". $error;}
	var_dump($res);

	//echo $result . " Records Inserted in DB" .$db->lastInsertID();
	
	
	
	
	
	