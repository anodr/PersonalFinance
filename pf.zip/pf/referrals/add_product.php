<?php ob_start(); 
session_start(); 
?>
<?php
try{
   require_once('../include/DB.php');
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
   if(isset($_POST) & !empty($_POST)){
   $CurrentTime=time();
   date_default_timezone_set('Africa/Dar_es_Salaam');
   $DateTime=strftime('%Y-%m-%d %H:%M:%S',$CurrentTime);
   if(isset($_SESSION['login'])){
		  $Admin = $_SESSION['id'];
		}

   $sql = "INSERT INTO products(productname,productcode,expirydate,dateproduct,addedby)
	       VALUES(:productname, :productcode, :expirydate, :dateproduct, :addedby)";
   $result = $conn->prepare($sql); 
   $result->bindParam(':productname', htmlspecialchars($_POST['productname']),PDO::PARAM_STR);
   $result->bindParam(':productcode', htmlspecialchars($_POST['productcode']),PDO::PARAM_STR);
   $result->bindParam(':expirydate', htmlspecialchars($_POST['expirydate']),PDO::PARAM_STR);
   $result->bindParam(':dateproduct', htmlspecialchars($DateTime),PDO::PARAM_STR);
   $result->bindParam(':addedby', htmlspecialchars($Admin),PDO::PARAM_STR);
   $res = $result->execute();
  if($res){
  $_SESSION["SuccessMessage"]="Product Added Successfully";
  header("Location: purchase.php");
  }else{
  $_SESSION["ErrorMessage"]="Something went wrong. Try again";
  header("Location: index.php");
  }
   
}
}catch(Exception $e){
	$error = $e->getMessage();

}
if(isset($error)){echo "Errors : ". $error;}
	var_dump($res);

	//echo $result . " Records Inserted in DB" .$db->lastInsertID();
	
	
	
	
	
	