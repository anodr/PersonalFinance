<?php ob_start(); 
session_start();
?>
<?php

try {
  require_once('../include/DB.php');
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  
  if(isset($_SESSION['login'])){
		  $Admin = $_SESSION['id'];
		}
  
  $sql = "DELETE FROM expenses WHERE addedexpense='$Admin' AND expense_id=?";
  $result = $conn->prepare($sql);
  $res = $result->execute(array($_GET['id']));
  if ($res) { 
	//header("location:javascript://history.go(-1)");
	$_SESSION["SuccessMessage"]="Expense Deleteted Successfully";
	header('Location: ' . $_SERVER['HTTP_REFERER']);
 }else{
	echo "Failed to Delete Record";
 }
  
 } catch (Exception $e) {
  $error = $e->getMessage();
}
