<?php ob_start(); ?>
<?php session_start(); ?>
<?php require_once("simplelogin/includes/connect.php"); ?>
<?php //require_once("../include/sessions.php"); ?> 
<?php require_once("simplelogin/includes/functions.php"); ?>
<?php ConfirmFrontPage_Login() ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta http-equiv="refresh" content="30" > 

  <title>PF - Personal Finance Software</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar" HIDDEN>

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon">
          <i class="fas fa-school"></i>
        </div>
        <div class="sidebar-brand-text mx-3">MySchool</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Basics
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-users"></i>
          <span title="Students registration">Students</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="students/admission.php">Student Admission</a>
			<a class="collapse-item" href="students/viewstudents.php">View Students</a>
			<a class="collapse-item" href="students/attendance.php">Attendance</a>
			<a class="collapse-item" href="students/attendancereport.php">Attendance Report</a>
			<a class="collapse-item" href="students/transferclass.php">Transfer Class</a>
          </div>
        </div>
      </li>
	  
	  <!-- Divider -->
      <hr class="sidebar-divider">
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
          <i class="far fa-credit-card"></i>
          <span title="Sell Products here">Fees (Cashier)</span>
        </a>
        <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="fees/pay.php">Fee Payment </a>
            <a class="collapse-item" href="fees/due.php">Fees Due</a>
			<a class="collapse-item" href="fees/paid.php">Paid List</a>
            <a class="collapse-item" href="fees/onlinepay.php">Online Fee Payment</a>			
          </div>
        </div>
      </li>

      <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-graduation-cap"></i>
          <span title="Enter Academics">Academics</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="academics/classes.php">Classes</a>
			<a class="collapse-item" href="academics/subjects.php">Subjects</a>
			<a class="collapse-item" href="academics/tests.php">Tests</a>
			<a class="collapse-item" href="academics/testresults.php">Test Results</a>
			<a class="collapse-item" href="academics/exams.php">Exams</a>
            <a class="collapse-item" href="academics/examresults.php">Exam Results</a>				
			<a class="collapse-item" href="academics/timetable.php">Create TimeTable</a>
			<a class="collapse-item" href="academics/notes.php">Notes</a>
			<a class="collapse-item" href="academics/quiz.php">Quizzes</a>
			<a class="collapse-item" href="academics/lessons.php">Lesson Planning</a>
			<a class="collapse-item" href="academics/classteacher.php">Class teacher allocation</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTheatre" aria-expanded="true" aria-controls="collapseTheatre">
          <i class="fas fa-laptop"></i>
          <span title="Enter Bought Products">Front Office</span>
        </a>
        <div id="collapseTheatre" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="reception/calls.php">Call & Follow-up</a>
			<a class="collapse-item" href="reception/inquiry.php">Inquiry</a>
			<a class="collapse-item" href="reception/complaints.php">Complaints</a>
			<a class="collapse-item" href="reception/visitors.php">Visitors</a>
			<a class="collapse-item" href="reception/latearrivals.php">Students Late arrival</a>
			<a class="collapse-item" href="reception/earlydepartures.php">Students Early Departure</a>
          </div>
        </div>
      </li>
	  
	  <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        <span title="View Students">Students</span>
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseDebtors" aria-expanded="true" aria-controls="collapseDebtors">
          <i class="fas fa-bus"></i>
          <span>Transport</span>
        </a>
        <div id="collapseDebtors" class="collapse" aria-labelledby="headingDebtors" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="transport/routes.php">Routes</a>
			<a class="collapse-item" href="transport/transportfees.php">Transport Fees</a>
			<a class="collapse-item" href="transport/destinations.php">Students' Destinations</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseCreditors" aria-expanded="true" aria-controls="collapseCreditors">
          <i class="fas fa-hotel"></i>
          <span>Hostel</span>
        </a>
        <div id="collapseCreditors" class="collapse" aria-labelledby="headingCreditors" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="hostels/hostel.php">Hostels</a>
			<a class="collapse-item" href="hostels/allocation.php">Hostels Allocation</a>
			<a class="collapse-item" href="hostels/hostelfees.php">Hostel Fees</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseInpatients" aria-expanded="true" aria-controls="collapseInpatients">
          <i class="fas fa-book"></i>
          <span>Library</span>
        </a>
        <div id="collapseInpatients" class="collapse" aria-labelledby="headingInpatients" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="library/library.php">Libraries</a>
			<a class="collapse-item" href="library/lent.php">Books Lent</a>
			<a class="collapse-item" href="library/returned.php">Books Returned</a>
			<a class="collapse-item" href="library/reports.php">Reports</a>
          </div>
        </div>
      </li>
	  	  
      <!-- Divider -->
      <hr class="sidebar-divider">
	  
	  <!-- Heading -->
      <div class="sidebar-heading">
        <span title="View Students">ADMINISTRATION & 
		FINANCE</span>
      </div>
	  
	   <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLabs" aria-expanded="true" aria-controls="collapseLabs">
          <i class="fas fa-user-tie"></i>
          <span>HR & Payroll</span>
        </a>
        <div id="collapseLabs" class="collapse" aria-labelledby="headingLabs" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
           <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="hr/staff.php">Employees</a>
			<a class="collapse-item" href="hr/departments.php">Departments</a>
			<a class="collapse-item" href="hr/leaves.php">Leave applications</a>
			<a class="collapse-item" href="hr/projects.php">Projects</a>
			<a class="collapse-item" href="hr/loans.php">Loans</a>
			<a class="collapse-item" href="hr/assets.php">Assets</a>
			<a class="collapse-item" href="hr/payroll.php">Payroll</a>
			<a class="collapse-item" href="hr/board.php">Notice Board</a>
			<a class="collapse-item" href="hr/reports.php">Reports</a>
           </div>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePharmacy" aria-expanded="true" aria-controls="collapsePharmacy">
          <i class="fas fa-chart-bar"></i>
          <span>Accounting / Finance</span>
        </a>
        <div id="collapsePharmacy" class="collapse" aria-labelledby="headingPharmacy" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="finance/bankaccounts.php">School Accounts</a>
			<a class="collapse-item" href="finance/expenses.php">Expenses</a>
			<a class="collapse-item" href="finance/income.php">Income</a>
			<a class="collapse-item" href="finance/daybook.php">Day Book</a>
			<a class="collapse-item" href="finance/cashbook.php">Cash Book</a>
			<a class="collapse-item" href="finance/bankbook.php">Bank Book</a>
			<a class="collapse-item" href="finance/reports.php">Reports</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseX-Ray" aria-expanded="true" aria-controls="collapseX-Ray">
          <i class="fas fa-boxes"></i>
          <span>Store Management</span>
        </a>
        <div id="collapseX-Ray" class="collapse" aria-labelledby="headingX-Ray" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="store/suppliers.php">Suppliers</a>			
			<a class="collapse-item" href="store/purchase.php">Purchase</a>
			<a class="collapse-item" href="store/consumed.php">Consumed/Used</a>
			<a class="collapse-item" href="store/inventory.php">Inventory</a>
			<a class="collapse-item" href="store/issued.php">Goods Issued</a>
			<a class="collapse-item" href="store/report.php">Reports</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFleet" aria-expanded="true" aria-controls="collapseFleet">
          <i class="fas fa-gas-pump"></i>
          <span>Fleet Management</span>
        </a>
        <div id="collapseFleet" class="collapse" aria-labelledby="headingFleet" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="fleet/fuel.php">Fuel</a>			
			<a class="collapse-item" href="fleet/service.php">Fleet Service</a>
			<a class="collapse-item" href="fleet/spare.php">Spare Parts</a>
			<a class="collapse-item" href="fleet/drivers.php">Drivers & Salary</a>
			<a class="collapse-item" href="fleet/report.php">Reports</a>
			<a class="collapse-item" href="fleet/dashboard.php">Dashboard</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseClinicalservices" aria-expanded="true" aria-controls="collapseClinicalservices">
          <i class="fas fa-folder-open"></i>
          <span>Reports</span>
        </a>
        <div id="collapseClinicalservices" class="collapse" aria-labelledby="headingClinicalservices" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="reports/studentsreport.php">Students Reports</a>
			<a class="collapse-item" href="reports/feesduereport.php">Fees Due Report</a>
			<a class="collapse-item" href="reports/feespaidreport.php">Fees Paid Report</a>
			<a class="collapse-item" href="reports/absentees.php">Absentees Report</a>
          </div>
        </div>
      </li>
	  
	  <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseDispensing" aria-expanded="true" aria-controls="collapseDispensing">
          <i class="fas fa-cogs"></i>
          <span>Settings</span>
        </a>
        <div id="collapseDispensing" class="collapse" aria-labelledby="headingDispensing" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="settings/institution.php">Institution Details</a>
			<a class="collapse-item" href="settings/academic.php">Academic Details</a>
			<a class="collapse-item" href="settings/importstudents.php">Students Import</a>
			<a class="collapse-item" href="settings/users.php">System Users</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form>

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
			
            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
					<?php 
		          if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				     }
					 
                 require_once('simplelogin/includes/connect.php');

                 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   
                 $res1 = $conn->prepare("SELECT username as Username FROM users WHERE id='$ID'");
                 $res1->execute();
	             $row = $res1->fetch(PDO::FETCH_ASSOC);
	             
				 $User = ($row['Username']);
				 
	             echo "<span class=''>".($row['Username'])."</span>";
	             ?>
		       </span>
                <img class="img-profile rounded-circle" src="img/user.png">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="../simplelogin/logout.php" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <div class="row">
          <div class="col-md-6 d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Matumizi / Expenses <small class="h5 text-center"><?php echo "<span class=''>".($row['Username'])."</span>"; ?></small></h1>
          </div>
 
         </div> 
		 
		 
		 
<div class="row">

<div class="col-md-6">  

<div class="card">
 <div class="card-body">
     
     <div class="row" HIDDEN>
	  <div class="col-md-6">
	    <small><a href="" data-toggle="modal" data-target="#myExpenses">Add Expense Name</a></small> 	 
	  </div>
	 </div><br>
     
<form action="add_expenses.php" method="POST" enctype="multipart/form-data" autocomplete="off">

<div class="table-responsive">
  <table class="table table-hover table-sm">
    <tr>
     <td>
      <label for="product">Matumizi/Expenses:</label>
     </td>
     <td>      
	  <select class="form-control" id="expensename" name="expensename">	 
		 <?php
           try{
              require_once('include/DB.php');
			  
			  if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }

              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
              $stmt = $conn->prepare("SELECT * FROM expensecat WHERE expensecatby='$ID' ORDER BY expensecatname ASC");
              $stmt->execute();
	          $SrNo=0;

              $stmt->bindColumn('expensecat_id', $Id);
              $stmt->bindColumn('expensecatname', $expensecatname);

              $errorInfo = $conn->errorInfo();
              print_r($errorInfo);
              if (isset($errorInfo[2])) {
   	          $error = $errorInfo[2];
                   }
                 }catch(Exception $e){
	          $error = $e->getMessage();
                 }
              if(isset($error)){echo "Errors : ". $error;}
			  echo '<option value="">Choose...</option>';
			  echo '<option value="Nauli">Nauli</option>';
			  echo '<option value="Drinks">Drinks</option>';
			  echo '<option value="Food">Food</option>';
			  echo '<option value="Food">Umeme</option>';
			  echo '<option value="Kodi">Kodi</option>';
			  echo '<option value="Mengineyo">Mengineyo</option>';
			  while ($row = $stmt->fetch()) {
              $SrNo++;
	             ?>
				<option><?php echo htmlentities($expensecatname); ?></option>
		           <?php } ?>    
		  </select>
	 </td>
    </tr>
	<tr>
     <td>
      <label for="quantity">Kiasi/Amount:</label>
     </td>
     <td>
      <input type="number" id="quantity" name="expenseamount" class="form-control" required>
     </td>
    </tr>
 </table>
</div> 
    <input type="Submit" class="btn btn-sm btn-primary btn-block" id="btnAddProduct" value="Save" >
</form>

</div>
</div>


<hr>

</div>

 </div>
		 
		 
		 
		 
		 
		 
		 <?php  //include_once("charts/kukoboa.php"); ?>

          <!-- Content Row -->
          <div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">MATUMIZI (Today)</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
					    
						
<?php
    require_once('include/DB.php');
	
	$Today=strtotime("Yesterday Midnight");
	
	$Start = date("Y-m-d 00:00:00",$Today);
	
	date_default_timezone_set('Africa/Dar_es_Salaam');
    
	date("Y-m-d H:i:s");
    
	$Finish = date("Y-m-d H:i:s");
	
	if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }
	
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$res1 = $conn->prepare("SELECT SUM(expenseamount) as totalFees FROM expenses WHERE dateexpense BETWEEN '$Start' AND '$Finish' AND addedexpense='$ID'");
    $res1->execute();
	$row = $res1->fetch(PDO::FETCH_ASSOC);
	
	echo "<a href='#' class=''>";
      echo "<span class='pull-right'>".number_format($row['totalFees'])."</span>";
	echo "</a>";

?>  
					  </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-money-bill-alt fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">MATUMIZI (This Week)</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
					  
<?php
    require_once('include/DB.php');
	
	$Sunday=strtotime("Last Sunday Midnight");
	
	$Start = date("Y-m-d 00:00:00",$Sunday);
	
	date_default_timezone_set('Africa/Dar_es_Salaam');
    
	date("Y-m-d H:i:s");
    
	$Finish = date("Y-m-d H:i:s");
	
	if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }
	
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$res1 = $conn->prepare("SELECT SUM(expenseamount) as totalFees FROM expenses WHERE dateexpense BETWEEN '$Start' AND '$Finish' AND addedexpense='$ID'");
    $res1->execute();
	$row = $res1->fetch(PDO::FETCH_ASSOC);
	
	echo "<a href='#' class=''>";
      echo "<span class='pull-right'>".number_format($row['totalFees'])."</span>";
	echo "</a>";

?>
	</div>
      </div>
        <div class="col-auto">
                      <i class="fas fa-money-bill-alt fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">MATUMIZI (This Month)</div>
                      <div class="row no-gutters align-items-center">
                        <div class="col-auto">
                          <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
						  
<?php
    require_once('include/DB.php');
	
	$ThisMonth=strtotime("Last day of last month midnight");
	
	$Start = date("Y-m-d 00:00:00",$ThisMonth);
	
	date_default_timezone_set('Africa/Dar_es_Salaam');
    
	date("Y-m-d H:i:s");
    
	$Finish = date("Y-m-d H:i:s");
	
	if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }
	
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$res1 = $conn->prepare("SELECT SUM(expenseamount) as totalFees FROM expenses WHERE dateexpense BETWEEN '$Start' AND '$Finish' AND addedexpense='$ID'");
    $res1->execute();
	$row = $res1->fetch(PDO::FETCH_ASSOC);
	
	echo "<a href='#' class=''>";
     echo "<span class='pull-right'>".number_format($row['totalFees'])."</span>";
	echo "</a>";

?>
	</div>
       </div>
           </div>
            </div>
              <div class="col-auto">
                <i class="fas fa-money-bill-alt fa-2x text-gray-300"></i>
              </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-success text-uppercase mb-1">MATUMIZI (This Year)</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">
<?php
    require_once('include/DB.php');
	
	$LastYear=strtotime("Last day of december last year");
	
	$Start = date("Y-m-d 00:00:00",$LastYear);
	
	date_default_timezone_set('Africa/Dar_es_Salaam');
    
	date("Y-m-d H:i:s");
    
	$Finish = date("Y-m-d H:i:s");
	
	if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }
	
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	$res1 = $conn->prepare("SELECT SUM(expenseamount) as totalFees FROM expenses WHERE dateexpense BETWEEN '$Start' AND '$Finish' AND addedexpense='$ID'");
    $res1->execute();
	$row = $res1->fetch(PDO::FETCH_ASSOC);
	
	echo "<a href='#' class=''>";
      echo "<span class='pull-right'>".number_format($row['totalFees'])."</span>";
	echo "</a>";

?>
	</div>
      </div>
         <div class="col-auto">
           <i class="fas fa-money-bill-alt fa-2x text-gray-300"></i>
         </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
		  
		  
		  <!-- Content Row -->
          <div class="row">

            <!-- Content Column -->
            <div class="col-lg-12 mb-4">

              <!-- Project Card Example -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Matumizi kwa Wiki hii</h6>
                </div>
                <div class="chart-area">
				    <?php  include_once("charts/matumiziwikichart.php"); ?>  
				</div>
              </div>
            </div>
			
          </div>

          <!-- Content Row -->

          <div class="row">

            <!-- Area Chart -->
            <div class="col-xl-7 col-lg-7">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Graph ya Matumizi</h6>
                  <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                      <div class="dropdown-header">Graphs:</div>
                      <a class="dropdown-item" href="#">Action</a>
                      <a class="dropdown-item" href="#">Action</a>
                    </div>
                  </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="chart-area">
				    <?php include_once("charts/expenseschart.php"); ?>  
				  </div>
                </div>
              </div>
            </div>

            <!-- Pie Chart -->
            <div class="col-xl-5 col-lg-5">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Siku 10 za matumizi makubwa</h6>
                  <div class="dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink">
                      <div class="dropdown-header">Graphs:</div>
                      <a class="dropdown-item" href="#">Action</a>
                      <a class="dropdown-item" href="#">Action</a>
                    </div>
                  </div>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="chart-pie pt-4 pb-2">
                    <?php  include_once("charts/matumizimakubwachart.php"); ?>  
				  </div>
                  <div class="mt-4 text-center small">
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
          
		  
		 
		  <!-- Content Row -->
          <div class="row">

            <!-- Content Column -->
            <div class="col-lg-12 mb-4">

              <!-- Project Card Example -->
              <div class="card shadow mb-4">
                <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Matumizi / Expenses <?php echo $User; ?></h6>
                </div>
                <div class="">
				    <?php  include_once("charts/expenses.php"); ?>  
				</div>
              </div>
            </div>
			
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Startpoint &copy <?php echo date('Y'); ?></span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="simplelogin/logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
  
  <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

</body>

</html>
