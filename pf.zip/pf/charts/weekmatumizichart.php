<?php require('include/DB.php');?>

<?php
  try {
		
	$Sunday=strtotime("Last Sunday Midnight");
	$Start = date("Y-m-d 00:00:00",$Sunday);
	date_default_timezone_set('Africa/Dar_es_Salaam');
	date("Y-m-d H:i:s");
	$Finish = date("Y-m-d H:i:s");
	
	if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }

    $result = $conn->query("SELECT *,dateused, DATE_FORMAT(dateused, '%Y %M %D') as d, 
			                SUM(quantity) as Matumizi FROM consumed WHERE dateused BETWEEN '$Start' AND '$Finish' AND addedby='$ID'
							GROUP BY d ORDER BY dateused DESC");												  

      $rows = array();
      $table = array();
      $table['cols'] = array(

        // Labels for your chart, these represent the column titles.
        /* 
            note that one column is in "string" format and another one is in "number" format 
            as pie chart only required "numbers" for calculating percentage 
            and string will be used for Slice title
        */

        array('label' => 'd', 'type' => 'string'),
        array('label' => 'Matumizi', 'type' => 'number')

    );
        /* Extract the information from $result */
        foreach($result as $r) {

          $temp = array();

          // the following line will be used to slice the Pie chart

          $temp[] = array('v' => (string) $r['d']); 

          // Values of each slice

          $temp[] = array('v' => (int) $r['Matumizi']); 
          $rows[] = array('c' => $temp);
        }

    $table['rows'] = $rows;

    // convert data into JSON format
    $jsonTable = json_encode($table);
    //echo $jsonTable;
    } catch(PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
    }

    ?>
	   

    <!--Load the Ajax API-->
        <script src="https://www.gstatic.com/charts/loader.js"></script>

		
		<script type="text/javascript">

        google.charts.load('current', {packages: ['corechart']});
        google.charts.setOnLoadCallback(drawChart);


        function drawChart() {

          // Create our data table out of JSON data loaded from server.
          var data = new google.visualization.DataTable(<?=$jsonTable?>);
          var options = {
               title: 'WEEKLY MATUMIZI GRAPH',
              is3D: 'false',
              height: 265
            };
          // Instantiate and draw our chart, passing in some options.
          // Do not forget to check your div ID
          var chart = new google.visualization.SteppedAreaChart(document.getElementById('chart_div679'));
          chart.draw(data, options);
        }
		
		$(window).resize(function(){
         drawChart();
        });
		
        </script>
	  
	  
	   <div id="chart_div679" class="card card-body col-md-12 chart-area"></div>
	  
<br>
