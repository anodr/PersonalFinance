
<div class="container-fluid">

  <div class="card shadow mb-4">
    <div class="card-header py-3">
              
	<?php
    require_once('include/DB.php');
   
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }
   
	$res1 = $conn->prepare("SELECT SUM(expenseamount) as Amount FROM expenses
									  WHERE addedexpense='$ID'");
    $res1->execute();
	$row = $res1->fetch(PDO::FETCH_ASSOC);
	
	$Paid = ($row['Amount']);
	
	echo "<h6>";
	  echo 'Paid Amount:&nbsp;';  echo "<span class='pull-right'>".number_format($row['Amount'])."</span>";
	echo "</h6>";
    ?>			
  </div>

<div class="card-body">
 <div class="table-responsive">
  <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
   <thead>
    <tr>
      <th>No.</th>
      <th>Expense</th>
	  <th>Paid</th>
	  <th>Date</th>
	  <th></th>
    </tr>
   </thead>
   <tbody>
   <?php
         try{
              require_once('include/DB.php');

              $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			  $stmt = $conn->prepare("SELECT * FROM expenses
									  WHERE addedexpense='$ID' ORDER BY dateexpense DESC");		  
              $stmt->execute();
	          $SrNo=0;
              $stmt->bindColumn('expense_id', $Id);
			  $stmt->bindColumn('expensename', $expensename);
			  $stmt->bindColumn('expensesupplier', $expensesupplier);
              $stmt->bindColumn('expenseamount', $expenseamount);
			  $stmt->bindColumn('requiredamount', $requiredamount);
			  $stmt->bindColumn('dateexpense', $DateTime);

              $errorInfo = $conn->errorInfo();
              //print_r($errorInfo);
              if (isset($errorInfo[2])) {
   	          $error = $errorInfo[2];
                   }
                 }catch(Exception $e){
	          $error = $e->getMessage();
                 }
              if(isset($error)){echo "Errors : ". $error;}
              while ($row = $stmt->fetch()) {
              $SrNo++;
	             ?>		  
  <tr>
    <td><?php echo $SrNo; ?></td>
	<td><a href="expensedata.php?id=<?php echo $expensecat_id; ?>"><?php echo $expensename; ?></a></td>
	<td><?php echo number_format($expenseamount); ?></td>
	<td><?php echo ($DateTime); ?></td>
	<td><a href="delete_expense.php?id=<?php echo $Id; ?>"><i class="fas fa-trash" style="color:gray;"></i></a></td>
  </tr>
 <?php } ?>				
  </tbody>
  </table>
  </div>
  </div>
  </div>

</div>

