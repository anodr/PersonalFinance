<?php require('include/DB.php');?>

<?php
  try {
		
	$LastYear=strtotime("Last day of december last year");
	
	$Start = date("Y-m-d 00:00:00",$LastYear);
	
	date_default_timezone_set('Africa/Dar_es_Salaam');
    
	date("Y-m-d H:i:s");
    
	$Finish = date("Y-m-d H:i:s");

    if(isset($_SESSION['login'])){
		           $ID = $_SESSION['id'];
				  }	
		
    $result = $conn->query("SELECT *, SUM(amount) as TotalExpenses, classmiscfees AS Miscfees FROM schoolmiscfees
	                        WHERE miscfeesby='$ID' GROUP BY Miscfees ORDER BY TotalExpenses");

      $rows = array();
      $table = array();
      $table['cols'] = array(

        // Labels for your chart, these represent the column titles.
        /* 
            note that one column is in "string" format and another one is in "number" format 
            as pie chart only required "numbers" for calculating percentage 
            and string will be used for Slice title
        */

        array('label' => 'Miscfees', 'type' => 'string'),
        array('label' => 'Amount', 'type' => 'number')

    );
        /* Extract the information from $result */
        foreach($result as $r) {

          $temp = array();

          // the following line will be used to slice the Pie chart

          $temp[] = array('v' => (string) $r['Miscfees']); 

          // Values of each slice

          $temp[] = array('v' => (int) $r['TotalExpenses']); 
          $rows[] = array('c' => $temp);
        }

    $table['rows'] = $rows;

    // convert data into JSON format
    $jsonTable = json_encode($table);
    //echo $jsonTable;
    } catch(PDOException $e) {
        echo 'ERROR: ' . $e->getMessage();
    }

    ?>	   

    <!--Load the Ajax API-->

<script type="text/javascript">

        google.charts.load('current', {packages: ['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

          // Create our data table out of JSON data loaded from server.
          var data = new google.visualization.DataTable(<?=$jsonTable?>);
          var options = {
               title: 'MISC FEES PAYMENT ACCORDING TO CLASSES',
              is3D: 'false',
              height: 259,
			  pieHole: 0.2,
			  legend: 'none',
          pieSliceText: 'none',
		  enableInteractivity: 'true',


            };
          // Instantiate and draw our chart, passing in some options.
          // Do not forget to check your div ID
          var chart = new google.visualization.PieChart(document.getElementById('donutchart'));
          chart.draw(data, options);
        }
        </script>
	  
	  
	   <div id="donutchart" class="col-md-12 chart-area"></div>
	  
<br>
